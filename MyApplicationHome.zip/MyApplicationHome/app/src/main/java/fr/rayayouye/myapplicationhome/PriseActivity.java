package fr.rayayouye.myapplicationhome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;

import tech.gusavila92.websocketclient.WebSocketClient;

public class PriseActivity extends AppCompatActivity {

    private WebSocketClient webSocketClient;
    private Button buttonRtrPrise;
    private Button buttonActPris;
    private Button buttonActu;
    private Button buttonActuOFF;
    private TextView textEtat;
    private boolean isWebSocketConnected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prise);

        ///////////////////////////// Déclaration et initialisation //////////////////////////

        this.buttonRtrPrise = (Button) findViewById(R.id.buttonRtrPrise);
        this.buttonActPris = (Button) findViewById(R.id.buttonActPris);
        this.buttonActu = (Button) findViewById(R.id.buttonActu);
        this.buttonActuOFF = (Button) findViewById(R.id.buttonActuOFF);
        this.textEtat = findViewById(R.id.textEtat);

        //////////////BUTTON RETOUR ////////////

        buttonRtrPrise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        ///////////// BUTTON ACTU PRISE ///////////////////

        buttonActPris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendWebSocketRequest("ws://172.20.10.6:1880/ws/prise", textEtat, " ");
            }
        });

        ///////////////// BOUTON ALLUMER  ///////////////////////////

        buttonActu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeWebSocketRequest("ws://172.20.10.6:1880/ws/chgprise", textEtat, " ", "1");

            }
        });

        ///////////////// BOUTON ETEINDRE  ///////////////////////////

        buttonActuOFF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeWebSocketRequest("ws://172.20.10.6:1880/ws/chgprise", textEtat, " ", "0");

            }
        });

    }

    /////////////////////////////// WEB SOCKET //////////////////////////////////////////////////
    private void createWebSocketClient(String uriString, final TextView textView, final String unit) {
        try {
            URI uri = new URI(uriString);

            webSocketClient = new WebSocketClient(uri) {
                @Override
                public void onOpen() {
                    Log.i("WebSocket", "Session is starting");
                    webSocketClient.send("Vous êtes connecté !");
                    isWebSocketConnected = true;
                }

                @Override
                public void onTextReceived(String s) {
                    Log.i("WebSocket", "Message received");
                    final String message = s;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                textView.setText(message + unit);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }

                @Override
                public void onBinaryReceived(byte[] data) {
                }

                @Override
                public void onPingReceived(byte[] data) {
                }

                @Override
                public void onPongReceived(byte[] data) {
                }

                @Override
                public void onException(Exception e) {
                    System.out.println(e.getMessage());
                }

                @Override
                public void onCloseReceived() {
                    Log.i("WebSocket", "Closed");
                    System.out.println("onCloseReceived");
                    isWebSocketConnected = false;
                }
            };

            webSocketClient.setConnectTimeout(10000);
            webSocketClient.setReadTimeout(60000);
            webSocketClient.enableAutomaticReconnection(5000);
            webSocketClient.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }
    //////////////// FONCTION DU WEBSOCKET ME PERMETANT DE RECUPERER UNE VALEUR //////////////////////////
    private void sendWebSocketRequest(String uriString, final TextView textView, final String unit) {
        if (isWebSocketConnected) {
            webSocketClient.send("envoie en cours......");
            JSONObject json = new JSONObject();
            try {
                json.put("action", "getStatus");
                json.put("deviceId", "1864kl"); // Remplacez "12345" par l'ID de votre appareil.
            } catch (JSONException e) {
                e.printStackTrace();
            }
            webSocketClient.send(json.toString());
        }

        createWebSocketClient(uriString, textView, unit);
    }

//////////////// FONCTION DU WEBSOCKET ME PERMETANT DE MODIFIER UNE VALEUR //////////////////////////
    private void changeWebSocketRequest(String uriString, final TextView textView, final String unit, String newValue ) {
        if (isWebSocketConnected) {
            webSocketClient.send("envoie en cours......");
            JSONObject json = new JSONObject();
            try {
                json.put("action", "changeValue");
                json.put("deviceId", "1864kl"); // ID de votre appareil.
                json.put("newValue", newValue);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            webSocketClient.send(json.toString());
        }

        createWebSocketClient(uriString, textView, unit);
    }


}
