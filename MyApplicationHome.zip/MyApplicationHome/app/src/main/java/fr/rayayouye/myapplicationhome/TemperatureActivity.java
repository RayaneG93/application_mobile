package fr.rayayouye.myapplicationhome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;

import tech.gusavila92.websocketclient.WebSocketClient;

public class TemperatureActivity extends AppCompatActivity {

    private WebSocketClient webSocketClient;
    private boolean isWebSocketConnected = false;
    private Button buttonRtrTemp;
    private ImageButton imageButtonLum;
    private ImageButton imageButtonTemp;
    private ImageButton imageButtonHum;
    private TextView valTemp;
    private TextView valHum;
    private TextView valLum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);

        ///////////////////////////// Déclaration et initialisation //////////////////////////

        valTemp = findViewById(R.id.valTemp);
        valHum = findViewById(R.id.valHum);
        valLum = findViewById(R.id.valLum);
        buttonRtrTemp = findViewById(R.id.buttonRtrTemp);
        imageButtonTemp = findViewById(R.id.imageButtonActTemp);
        imageButtonHum = findViewById(R.id.imageButtonHum);
        imageButtonLum = findViewById(R.id.imageButtonLum);

        buttonRtrTemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        imageButtonTemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendWebSocketRequest("ws://172.20.10.6:1880/ws/temp", valTemp, " °C");
            }
        });

        imageButtonHum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendWebSocketRequest("ws://172.20.10.6:1880/ws/humid", valHum, " %");
            }
        });

        imageButtonLum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendWebSocketRequest("ws://172.20.10.6:1880/ws/lux", valLum, " Lux");
            }
        });
    }

    private void createWebSocketClient(String uriString, final TextView textView, final String unit) {
        try {
            URI uri = new URI(uriString);

            webSocketClient = new WebSocketClient(uri) {
                @Override
                public void onOpen() {
                    Log.i("WebSocket", "Session is starting");
                    webSocketClient.send("Vous êtes connecté !");
                    isWebSocketConnected = true;
                }

                @Override
                public void onTextReceived(String s) {
                    Log.i("WebSocket", "Message received");
                    final String message = s;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                textView.setText(message + unit);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }

                @Override
                public void onBinaryReceived(byte[] data) {
                }

                @Override
                public void onPingReceived(byte[] data) {
                }

                @Override
                public void onPongReceived(byte[] data) {
                }

                @Override
                public void onException(Exception e) {
                    System.out.println(e.getMessage());
                }

                @Override
                public void onCloseReceived() {
                    Log.i("WebSocket", "Closed");
                    System.out.println("onCloseReceived");
                    isWebSocketConnected = false;
                }
            };

            webSocketClient.setConnectTimeout(10000);
            webSocketClient.setReadTimeout(60000);
            webSocketClient.enableAutomaticReconnection(5000);
            webSocketClient.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    private void sendWebSocketRequest(String uriString, final TextView textView, final String unit) {
        if (isWebSocketConnected) {
            webSocketClient.send("récuperation en cours ...");
            JSONObject json = new JSONObject();
            try {
                json.put("action", "getStatus");
                json.put("deviceId", "1548");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            webSocketClient.send(json.toString());
        }
        createWebSocketClient(uriString, textView, unit);
    }
}
