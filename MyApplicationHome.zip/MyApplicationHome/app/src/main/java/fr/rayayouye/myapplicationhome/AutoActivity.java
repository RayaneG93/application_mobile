package fr.rayayouye.myapplicationhome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AutoActivity extends AppCompatActivity {

    private Button buttonRtrAuto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto);

        //////////////BUTTON RETOUR ////////////
        this.buttonRtrAuto = (Button) findViewById(R.id.buttonRtrAuto);

        buttonRtrAuto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });
    }
}