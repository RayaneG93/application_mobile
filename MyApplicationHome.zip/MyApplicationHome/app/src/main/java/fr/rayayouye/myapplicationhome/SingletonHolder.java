package fr.rayayouye.myapplicationhome;

public class SingletonHolder {
    public static SocketClient socketClient;

    public static void setSocketClient(SocketClient client) {
        socketClient = client;
    }

    public static SocketClient getSocketClient() {
        return socketClient;
    }
}



