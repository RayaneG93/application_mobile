package fr.rayayouye.myapplicationhome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;


public class MainActivity extends AppCompatActivity {

    private Socket client;
    private Button buttonTemperature;
    private Button buttonHum;
    private Button buttonLum;
    private Button buttonSuivant;

    private Button connectButton;

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
        /////// IP DU SERVEUR AVEC SON PORT ///////////
    private final String ip = "172.20.10.6";
    private final int port = 1880;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //////////////BUTTON CONNEXION ////////////
        connectButton = findViewById(R.id.A);

        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SocketClient client = new SocketClient(ip, port);
                        client.connect();

                        if (client.isConnected()) {
                            // Affiche un message indiquant que la connexion est réussie
                            showToast("Connecté au serveur distant");

                            // Ajoutez votre code pour envoyer et recevoir des messages ici
                            client.sendMessage("IHM mobile connectée");

                            // Stocke l'objet SocketClient dans le SingletonHolder
                            SingletonHolder.socketClient = client;
 
                            // Affiche un message indiquant que la connexion a reussi
                            showToast("Connexion au serveur réussi");
                        } else {
                            // Affiche un message indiquant que la connexion a échoué
                            showToast("Échec de la connexion au serveur");
                        }
                    }
                }).start();
            }
        });




        //////////////BUTTON TEMPERATURE ////////////
        this.buttonTemperature = (Button) findViewById(R.id.buttonTemperature);

        buttonTemperature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), TemperatureActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        //////////////BUTTON PRISE CONNECTER ////////////
        this.buttonHum = (Button) findViewById(R.id.buttonPrise);

        buttonHum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), PriseActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        /////////////BUTTON PORTE ////////////
        this.buttonLum = (Button) findViewById(R.id.buttonPorte);

        buttonLum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), DetecteurActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        /////////////BUTTON SUIVANT ////////////
        this.buttonSuivant = (Button) findViewById(R.id.buttonSuivant);

        buttonSuivant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent otherActivity = new Intent(getApplicationContext(), AutoActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });


    }
}